(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["plugins/gift/components/announcement/gift-navigation"],{"022c":function(t,n,e){"use strict";e.r(n);var a=e("bfcf"),u=e.n(a);for(var o in a)"default"!==o&&function(t){e.d(n,t,function(){return a[t]})}(o);n["default"]=u.a},"38b5":function(t,n,e){},"3a76":function(t,n,e){"use strict";var a=e("38b5"),u=e.n(a);u.a},"5aa0":function(t,n,e){"use strict";var a=function(){var t=this,n=t.$createElement;t._self._c},u=[];e.d(n,"a",function(){return a}),e.d(n,"b",function(){return u})},aaa8:function(t,n,e){"use strict";e.r(n);var a=e("5aa0"),u=e("022c");for(var o in u)"default"!==o&&function(t){e.d(n,t,function(){return u[t]})}(o);e("3a76");var r=e("2877"),c=Object(r["a"])(u["default"],a["a"],a["b"],!1,null,"032bf206",null);n["default"]=c.exports},bfcf:function(t,n,e){"use strict";(function(t){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var e={name:"gift-navigation",props:["theme","botHeight","navBool"],data:function(){return{tab_route:"",load_success:!1}},created:function(){var t=getCurrentPages();this.tab_route=t[t.length-1].route},methods:{routeGo:function(n){t.redirectTo({url:n})}}};n.default=e}).call(this,e("5486")["default"])}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'plugins/gift/components/announcement/gift-navigation-create-component',
    {
        'plugins/gift/components/announcement/gift-navigation-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('5486')['createComponent'](__webpack_require__("aaa8"))
        })
    },
    [['plugins/gift/components/announcement/gift-navigation-create-component']]
]);                
