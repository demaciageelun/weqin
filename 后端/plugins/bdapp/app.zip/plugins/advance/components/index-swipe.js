(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["plugins/advance/components/index-swipe"],{3313:function(n,e,t){"use strict";t.r(e);var u=t("6377"),r=t.n(u);for(var a in u)"default"!==a&&function(n){t.d(e,n,function(){return u[n]})}(a);e["default"]=r.a},5897:function(n,e,t){},6377:function(n,e,t){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var u={name:"index-swipe",props:{pictures:{type:Array,default:function(){return[]}}},methods:{route_jump:function(n){this.$jump({url:n.page_url,open_type:n.open_type})}}};e.default=u},"6cd0":function(n,e,t){"use strict";t.r(e);var u=t("9c36"),r=t("3313");for(var a in r)"default"!==a&&function(n){t.d(e,n,function(){return r[n]})}(a);t("ecbd");var c=t("2877"),i=Object(c["a"])(r["default"],u["a"],u["b"],!1,null,"4ed4d09a",null);e["default"]=i.exports},"9c36":function(n,e,t){"use strict";var u=function(){var n=this,e=n.$createElement;n._self._c},r=[];t.d(e,"a",function(){return u}),t.d(e,"b",function(){return r})},ecbd:function(n,e,t){"use strict";var u=t("5897"),r=t.n(u);r.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'plugins/advance/components/index-swipe-create-component',
    {
        'plugins/advance/components/index-swipe-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('5486')['createComponent'](__webpack_require__("6cd0"))
        })
    },
    [['plugins/advance/components/index-swipe-create-component']]
]);                
