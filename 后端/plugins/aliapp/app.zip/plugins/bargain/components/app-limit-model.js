;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["plugins/bargain/components/app-limit-model"],{"054a":function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var u=function(){return e.e("components/basic-component/u-popup/u-popup").then(e.bind(null,"d55a"))},a={name:"app-limit-model",components:{uPopup:u},props:{showData:Object,value:{type:[Number,Boolean],default:!1}},data:function(){return{show:this.value}},watch:{value:function(n){this.show=n}},methods:{close:function(){this.$emit("input",!1)}}};t.default=a},"0611":function(n,t,e){"use strict";var u=function(){var n=this,t=n.$createElement;n._self._c},a=[];e.d(t,"a",function(){return u}),e.d(t,"b",function(){return a})},"36cb":function(n,t,e){"use strict";var u=e("4f7a"),a=e.n(u);a.a},"4f7a":function(n,t,e){},cdc3:function(n,t,e){"use strict";e.r(t);var u=e("0611"),a=e("f43a");for(var o in a)"default"!==o&&function(n){e.d(t,n,function(){return a[n]})}(o);e("36cb");var c=e("2877"),i=Object(c["a"])(a["default"],u["a"],u["b"],!1,null,"f8ff16a4",null);t["default"]=i.exports},f43a:function(n,t,e){"use strict";e.r(t);var u=e("054a"),a=e.n(u);for(var o in u)"default"!==o&&function(n){e.d(t,n,function(){return u[n]})}(o);t["default"]=a.a}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'plugins/bargain/components/app-limit-model-create-component',
    {
        'plugins/bargain/components/app-limit-model-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("cdc3"))
        })
    },
    [['plugins/bargain/components/app-limit-model-create-component']]
]);                
