;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["plugins/gift/components/order/switch-tab"],{"5e01":function(t,e,n){"use strict";var u=function(){var t=this,e=t.$createElement;t._self._c},r=[];n.d(e,"a",function(){return u}),n.d(e,"b",function(){return r})},"70ce":function(t,e,n){"use strict";var u=n("e744"),r=n.n(u);r.a},"7c1d":function(t,e,n){"use strict";n.r(e);var u=n("5e01"),r=n("b497");for(var a in r)"default"!==a&&function(t){n.d(e,t,function(){return r[t]})}(a);n("70ce");var i=n("2877"),c=Object(i["a"])(r["default"],u["a"],u["b"],!1,null,"d1f3ff4e",null);e["default"]=c.exports},b497:function(t,e,n){"use strict";n.r(e);var u=n("fe37"),r=n.n(u);for(var a in u)"default"!==a&&function(t){n.d(e,t,function(){return u[t]})}(a);e["default"]=r.a},e744:function(t,e,n){},fe37:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var u={name:"switch-tab",props:{theme:String},data:function(){return{tab_status:0}},methods:{getFormId:function(){},setTab:function(t){this.$emit("setTab",t),this.tab_status=t}}};e.default=u}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'plugins/gift/components/order/switch-tab-create-component',
    {
        'plugins/gift/components/order/switch-tab-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("7c1d"))
        })
    },
    [['plugins/gift/components/order/switch-tab-create-component']]
]);                
