;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["plugins/advance/components/detail-vip"],{"141c":function(n,t,e){"use strict";(function(n){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var e={name:"detail-vip",props:{discount:String,name:String},methods:{nav:function(){n.navigateTo({url:"/plugins/vip_card/index/index"})}}};t.default=e}).call(this,e("c11b")["default"])},"35bd":function(n,t,e){"use strict";e.r(t);var u=e("141c"),c=e.n(u);for(var i in u)"default"!==i&&function(n){e.d(t,n,function(){return u[n]})}(i);t["default"]=c.a},"526f":function(n,t,e){"use strict";e.r(t);var u=e("7b7b"),c=e("35bd");for(var i in c)"default"!==i&&function(n){e.d(t,n,function(){return c[n]})}(i);e("9cbf");var a=e("2877"),r=Object(a["a"])(c["default"],u["a"],u["b"],!1,null,"05976c03",null);t["default"]=r.exports},"7b7b":function(n,t,e){"use strict";var u=function(){var n=this,t=n.$createElement;n._self._c},c=[];e.d(t,"a",function(){return u}),e.d(t,"b",function(){return c})},"9cbf":function(n,t,e){"use strict";var u=e("c6b1"),c=e.n(u);c.a},c6b1:function(n,t,e){}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'plugins/advance/components/detail-vip-create-component',
    {
        'plugins/advance/components/detail-vip-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("526f"))
        })
    },
    [['plugins/advance/components/detail-vip-create-component']]
]);                
