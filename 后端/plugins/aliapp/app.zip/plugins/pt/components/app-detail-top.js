;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["plugins/pt/components/app-detail-top"],{"2e45":function(e,t,n){"use strict";n.r(t);var r=n("fe38"),i=n.n(r);for(var u in r)"default"!==u&&function(e){n.d(t,e,function(){return r[e]})}(u);t["default"]=i.a},"3f0f":function(e,t,n){"use strict";var r=function(){var e=this,t=e.$createElement;e._self._c},i=[];n.d(t,"a",function(){return r}),n.d(t,"b",function(){return i})},"60ce":function(e,t,n){"use strict";n.r(t);var r=n("3f0f"),i=n("2e45");for(var u in i)"default"!==u&&function(e){n.d(t,e,function(){return i[e]})}(u);n("e1a1");var a=n("2877"),c=Object(a["a"])(i["default"],r["a"],r["b"],!1,null,"0fca7e28",null);t["default"]=c.exports},be29:function(e,t,n){},e1a1:function(e,t,n){"use strict";var r=n("be29"),i=n.n(r);i.a},fe38:function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var r={name:"app-detail-top",props:{cover_pic:String,name:String,original_price:String,price:String,people_num:String,status:Number,group_economize_price:String,theme:Object}};t.default=r}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'plugins/pt/components/app-detail-top-create-component',
    {
        'plugins/pt/components/app-detail-top-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("60ce"))
        })
    },
    [['plugins/pt/components/app-detail-top-create-component']]
]);                
