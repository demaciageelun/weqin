;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["plugins/pt/components/app-pt-attr"],{"27cd":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var r={name:"app-pt-attr",props:{groups:{type:Array,default:function(){return[]}},selectGroupAttrId:String,theme:Object},methods:{active:function(t){this.$emit("click",t)}}};n.default=r},"2fd5":function(t,n,e){},3556:function(t,n,e){"use strict";e.r(n);var r=e("5e3f"),u=e("6569");for(var c in u)"default"!==c&&function(t){e.d(n,t,function(){return u[t]})}(c);e("a1cc");var a=e("2877"),f=Object(a["a"])(u["default"],r["a"],r["b"],!1,null,"111e939a",null);n["default"]=f.exports},"5e3f":function(t,n,e){"use strict";var r=function(){var t=this,n=t.$createElement;t._self._c},u=[];e.d(n,"a",function(){return r}),e.d(n,"b",function(){return u})},6569:function(t,n,e){"use strict";e.r(n);var r=e("27cd"),u=e.n(r);for(var c in r)"default"!==c&&function(t){e.d(n,t,function(){return r[t]})}(c);n["default"]=u.a},a1cc:function(t,n,e){"use strict";var r=e("2fd5"),u=e.n(r);u.a}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'plugins/pt/components/app-pt-attr-create-component',
    {
        'plugins/pt/components/app-pt-attr-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("3556"))
        })
    },
    [['plugins/pt/components/app-pt-attr-create-component']]
]);                
