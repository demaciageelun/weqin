;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["plugins/community/components/app-goods-time"],{"39b4":function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var u={name:"app-goods-time",props:{status:{type:Number},goods:{type:Object},hour:{type:String,default:function(){return 0}},minute:{type:String,default:function(){return 0}},second:{type:String,default:function(){return 0}},day:{type:Number,default:function(){return 0}},theme:Object}};e.default=u},"5f00":function(t,e,n){"use strict";var u=function(){var t=this,e=t.$createElement;t._self._c},r=[];n.d(e,"a",function(){return u}),n.d(e,"b",function(){return r})},"635e":function(t,e,n){"use strict";var u=n("ee62"),r=n.n(u);r.a},d213:function(t,e,n){"use strict";n.r(e);var u=n("39b4"),r=n.n(u);for(var o in u)"default"!==o&&function(t){n.d(e,t,function(){return u[t]})}(o);e["default"]=r.a},ee62:function(t,e,n){},fe14:function(t,e,n){"use strict";n.r(e);var u=n("5f00"),r=n("d213");for(var o in r)"default"!==o&&function(t){n.d(e,t,function(){return r[t]})}(o);n("635e");var a=n("2877"),f=Object(a["a"])(r["default"],u["a"],u["b"],!1,null,"33eaee21",null);e["default"]=f.exports}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'plugins/community/components/app-goods-time-create-component',
    {
        'plugins/community/components/app-goods-time-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("fe14"))
        })
    },
    [['plugins/community/components/app-goods-time-create-component']]
]);                
