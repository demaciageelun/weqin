;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["components/page-component/app-special-topic/app-special-topic-normal"],{"088c":function(t,n,e){},"26a4":function(t,n,e){"use strict";e.r(n);var c=e("5ead"),i=e("a70e");for(var u in i)"default"!==u&&function(t){e.d(n,t,function(){return i[t]})}(u);e("998c");var a=e("2877"),o=Object(a["a"])(i["default"],c["a"],c["b"],!1,null,"62140c42",null);n["default"]=o.exports},"59ca":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var c={name:"app-special-topic",props:{topic_list:{type:Array,default:function(){return[]}},count:{type:Number,default:function(){return 2}},icon:String,logo_1:String,logo_2:String},computed:{newDataList:function(){if(2===this.count){for(var t=[],n=0;n<Math.ceil(this.topic_list.length/this.count);n++)t.push(this.topic_list.slice(n*this.count,(n+1)*this.count));return t}}}};n.default=c},"5ead":function(t,n,e){"use strict";var c=function(){var t=this,n=t.$createElement;t._self._c},i=[];e.d(n,"a",function(){return c}),e.d(n,"b",function(){return i})},"998c":function(t,n,e){"use strict";var c=e("088c"),i=e.n(c);i.a},a70e:function(t,n,e){"use strict";e.r(n);var c=e("59ca"),i=e.n(c);for(var u in c)"default"!==u&&function(t){e.d(n,t,function(){return c[t]})}(u);n["default"]=i.a}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'components/page-component/app-special-topic/app-special-topic-normal-create-component',
    {
        'components/page-component/app-special-topic/app-special-topic-normal-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("26a4"))
        })
    },
    [['components/page-component/app-special-topic/app-special-topic-normal-create-component']]
]);                
