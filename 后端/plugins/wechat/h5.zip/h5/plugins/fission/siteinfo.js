module.exports = {
    'acid': -1,
    'version': '1.0.0',
    'siteroot': 'http://localhost/app/index.php',
    // 'apiroot': 'http://v4test6.zjhejiang.com/web/index.php?_mall_id=195'
    'apiroot': 'https://bd-test.zjhejiang.cn/web/index.php?_mall_id=1'
    // 'apiroot': 'http://localhost/zjhj_mall_v4/web/index.php?_mall_id=195'
    // 'apiroot': '/api/zjhj_mall_v4/web/index.php?_mall_id=1'
};