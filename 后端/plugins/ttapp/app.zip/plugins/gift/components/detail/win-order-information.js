(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["plugins/gift/components/detail/win-order-information"],{"3e0e":function(n,t,e){"use strict";var r=e("4d33"),u=e.n(r);u.a},"4d33":function(n,t,e){},7705:function(n,t,e){"use strict";e.r(t);var r=e("aef8"),u=e.n(r);for(var a in r)"default"!==a&&function(n){e.d(t,n,function(){return r[n]})}(a);t["default"]=u.a},"8b3b":function(n,t,e){"use strict";e.r(t);var r=e("bb17"),u=e("7705");for(var a in u)"default"!==a&&function(n){e.d(t,n,function(){return u[n]})}(a);e("3e0e");var o=e("2877"),i=Object(o["a"])(u["default"],r["a"],r["b"],!1,null,"04d0ca57",null);t["default"]=i.exports},aef8:function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var r={name:"win-order-information",props:["status","order_no","type","pay_time","open_time","open_num"]};t.default=r},bb17:function(n,t,e){"use strict";var r=function(){var n=this,t=n.$createElement;n._self._c},u=[];e.d(t,"a",function(){return r}),e.d(t,"b",function(){return u})}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'plugins/gift/components/detail/win-order-information-create-component',
    {
        'plugins/gift/components/detail/win-order-information-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f266')['createComponent'](__webpack_require__("8b3b"))
        })
    },
    [['plugins/gift/components/detail/win-order-information-create-component']]
]);                
