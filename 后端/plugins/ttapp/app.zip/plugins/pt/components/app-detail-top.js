(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["plugins/pt/components/app-detail-top"],{"0aba":function(e,t,n){"use strict";var r=function(){var e=this,t=e.$createElement;e._self._c},a=[];n.d(t,"a",function(){return r}),n.d(t,"b",function(){return a})},"2e45":function(e,t,n){"use strict";n.r(t);var r=n("fe38"),a=n.n(r);for(var i in r)"default"!==i&&function(e){n.d(t,e,function(){return r[e]})}(i);t["default"]=a.a},"60ce":function(e,t,n){"use strict";n.r(t);var r=n("0aba"),a=n("2e45");for(var i in a)"default"!==i&&function(e){n.d(t,e,function(){return a[e]})}(i);n("e1a1");var u=n("2877"),c=Object(u["a"])(a["default"],r["a"],r["b"],!1,null,"0fca7e28",null);t["default"]=c.exports},be29:function(e,t,n){},e1a1:function(e,t,n){"use strict";var r=n("be29"),a=n.n(r);a.a},fe38:function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var r={name:"app-detail-top",props:{cover_pic:String,name:String,original_price:String,price:String,people_num:String,status:Number,group_economize_price:String,theme:Object}};t.default=r}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'plugins/pt/components/app-detail-top-create-component',
    {
        'plugins/pt/components/app-detail-top-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f266')['createComponent'](__webpack_require__("60ce"))
        })
    },
    [['plugins/pt/components/app-detail-top-create-component']]
]);                
