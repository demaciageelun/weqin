(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["plugins/advance/components/index-swipe"],{3313:function(e,n,t){"use strict";t.r(n);var u=t("6377"),r=t.n(u);for(var a in u)"default"!==a&&function(e){t.d(n,e,function(){return u[e]})}(a);n["default"]=r.a},5897:function(e,n,t){},6377:function(e,n,t){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var u={name:"index-swipe",props:{pictures:{type:Array,default:function(){return[]}}},methods:{route_jump:function(e){this.$jump({url:e.page_url,open_type:e.open_type})}}};n.default=u},"6cd0":function(e,n,t){"use strict";t.r(n);var u=t("8d6e"),r=t("3313");for(var a in r)"default"!==a&&function(e){t.d(n,e,function(){return r[e]})}(a);t("ecbd");var c=t("2877"),i=Object(c["a"])(r["default"],u["a"],u["b"],!1,null,"4ed4d09a",null);n["default"]=i.exports},"8d6e":function(e,n,t){"use strict";var u=function(){var e=this,n=e.$createElement;e._self._c},r=[];t.d(n,"a",function(){return u}),t.d(n,"b",function(){return r})},ecbd:function(e,n,t){"use strict";var u=t("5897"),r=t.n(u);r.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'plugins/advance/components/index-swipe-create-component',
    {
        'plugins/advance/components/index-swipe-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f266')['createComponent'](__webpack_require__("6cd0"))
        })
    },
    [['plugins/advance/components/index-swipe-create-component']]
]);                
