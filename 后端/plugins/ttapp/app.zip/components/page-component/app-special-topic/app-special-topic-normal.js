(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/page-component/app-special-topic/app-special-topic-normal"],{"088c":function(t,n,c){},"26a4":function(t,n,c){"use strict";c.r(n);var e=c("c784"),i=c("a70e");for(var o in i)"default"!==o&&function(t){c.d(n,t,function(){return i[t]})}(o);c("998c");var u=c("2877"),a=Object(u["a"])(i["default"],e["a"],e["b"],!1,null,"62140c42",null);n["default"]=a.exports},"59ca":function(t,n,c){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var e={name:"app-special-topic",props:{topic_list:{type:Array,default:function(){return[]}},count:{type:Number,default:function(){return 2}},icon:String,logo_1:String,logo_2:String},computed:{newDataList:function(){if(2===this.count){for(var t=[],n=0;n<Math.ceil(this.topic_list.length/this.count);n++)t.push(this.topic_list.slice(n*this.count,(n+1)*this.count));return t}}}};n.default=e},"998c":function(t,n,c){"use strict";var e=c("088c"),i=c.n(e);i.a},a70e:function(t,n,c){"use strict";c.r(n);var e=c("59ca"),i=c.n(e);for(var o in e)"default"!==o&&function(t){c.d(n,t,function(){return e[t]})}(o);n["default"]=i.a},c784:function(t,n,c){"use strict";var e=function(){var t=this,n=t.$createElement;t._self._c},i=[];c.d(n,"a",function(){return e}),c.d(n,"b",function(){return i})}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/page-component/app-special-topic/app-special-topic-normal-create-component',
    {
        'components/page-component/app-special-topic/app-special-topic-normal-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f266')['createComponent'](__webpack_require__("26a4"))
        })
    },
    [['components/page-component/app-special-topic/app-special-topic-normal-create-component']]
]);                
